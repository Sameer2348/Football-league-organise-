
const mongoose = require("mongoose");
module.exports = mongoose.model("Player", new mongoose.Schema({
  wallet:String,
  points:{type:Number,default:0}
}));
