
import { useState } from "react";
import { connectWallet } from "../lib/wallet";

export default function Home() {
  const [wallet, setWallet] = useState(null);

  async function connect() {
    const w = await connectWallet();
    setWallet(w);
  }

  return (
    <div className="container">
      <h2>⚽ Crypto Football League</h2>
      {!wallet ? (
        <button className="btn" onClick={connect}>Connect Wallet</button>
      ) : (
        <div className="card">{wallet}</div>
      )}
    </div>
  );
}
